function setup(){
	
}

function loop(){
	
}

function onPressed(n){

}

function onMove(n){
	
}

function onReleased(n){

}
